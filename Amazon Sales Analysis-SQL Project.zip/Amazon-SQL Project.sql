-- This is Schema
use Amazon_DB;

-- Description of Database Table:
Select * From Amazon;


-- ||FEATURE ENGINEERING|| --
--------------------------------------------------------------------------------------------------------------------------------------------------
-- Step 1: Add a new column monthname
ALTER TABLE amazon ADD COLUMN MonthName VARCHAR(20);

-- Step 2: Update the new column with the monthname
UPDATE amazon SET monthname = CASE
			WHEN MONTH(Date) = 1 THEN 'January'
			WHEN MONTH(Date) = 2 THEN 'February'
			WHEN MONTH(Date) = 3 THEN 'March'
			WHEN MONTH(Date) = 4 THEN 'April'
			WHEN MONTH(Date) = 5 THEN 'May'
			WHEN MONTH(Date) = 6 THEN 'June'
			WHEN MONTH(Date) = 7 THEN 'July'
			WHEN MONTH(Date) = 8 THEN 'August'
			WHEN MONTH(Date) = 9 THEN 'September'
			WHEN MONTH(Date) = 10 THEN 'October'
			WHEN MONTH(Date) = 11 THEN 'November'
ELSE 'December'
END;
---------------------------------------------------------------------------------------------------------------------------------------------------
-- Step 1: Add a new column Days
ALTER TABLE amazon
ADD COLUMN Days VARCHAR(20); 

-- Step 2: Update the new column with days name
UPDATE amazon
SET Days = 
    CASE dayofweek(date)
        WHEN 1 THEN 'Sunday'
        WHEN 2 THEN 'Monday'
        WHEN 3 THEN 'Tuesday'
        WHEN 4 THEN 'Wednesday'
        WHEN 5 THEN 'Thursday'
        WHEN 6 THEN 'Friday'
        WHEN 7 THEN 'Saturday'
    END;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Add a new column 'TimeOfDay' to your table
ALTER TABLE amazon
ADD TimeOfDay VARCHAR(20);

-- Update the new column based on the timeofday column
UPDATE amazon
SET TimeOfDay = CASE
    -- Morning: From 00:00:00 to 11:59:59
    WHEN EXTRACT(HOUR FROM Time) >= 0 AND EXTRACT(HOUR FROM Time) < 12 THEN 'Morning'
    -- Afternoon: From 12:00:00 to 17:59:59
    WHEN EXTRACT(HOUR FROM Time) >= 12 AND EXTRACT(HOUR FROM Time) < 18 THEN 'Afternoon'
    -- Evening: From 18:00:00 to 23:59:59
    ELSE 'Evening'
END;
---------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------
-- BUSINESS QUESTIONS TO ANSWER:
--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q1 : What is the count of distinct cities in the dataset?
select count(distinct city) as 'Distinct Cities' from amazon;  -- distinct is used to remove duplicate row

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q2 : For each Branch, what is the corresponding city?
select distinct Branch,City from amazon;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q3 : What is the count of distinct product lines in the dataset?
select Count(distinct `Product line`) as 'Number Of ProductLine' from amazon;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q4 : Which payment method occurs most frequently?
select Payment,count(*) as frequently_Payment from amazon group by Payment order by frequently_Payment desc limit 1;
-- count(*) represent all rows count

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q5 : Which product line has the highest sales?
select `Product line`,Count(`Invoice ID`) as `Sales Count` from amazon group by `Product line` order by `Sales Count` desc limit 1;
-- group by keyword is used when aggregation present & used to group the column and order by used to filter the rows

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q6 : How much revenue is generated each month?
select Monthname,count(total) as Revenue from amazon group by Monthname order by Revenue desc;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q7 : In which month did the cost of goods sold reach its peak?
select Monthname,sum(cogs) as cogs_sold from amazon group by Monthname order by cogs_sold desc;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q8 : Which product line generated the highest revenue?
select `Product line`,Sum(Total) as Total_Revenue from amazon group by `Product line` order by Total_Revenue desc limit 1;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q9 : In which city was the highest revenue recorded?
select distinct City , sum(Total) as Revenue from amazon group by City order by Revenue desc;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q10 : Which product line incurred the highest Value Added Tax?
select `Product line`, sum(`Tax 5%`) as HighestVAT from amazon group by `Product line` order by HighestVAT Desc;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q11 : For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
select `Product line`,sum(Total) as TotalSales,
case when sum(Total) > (select Avg(Total) as avg from amazon) then "Good" else "Bad" end as SalesType
from amazon group by `Product line` order by TotalSales desc;
-- In this QUEARY Conditional Case/When statement is used. 

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q12 : Identify the branch that exceeded the average number of products sold.
select Distinct Branch,Sum(Quantity) as TOTALQuantity from amazon group by Branch having TOTALQuantity > (select AVG(Quantity) from amazon);
-- In this we used non-correlated Subquery.

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q13 : Which product line is most frequently associated with each gender?
select `Product line`,Gender,Count('Invoice ID') as Frequency from Amazon group by `Product line`,Gender order by Count('Invoice ID') desc;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q14 : Calculate the average rating for each product line.
select `Product line`,Avg(Rating) as AVG_RATING from Amazon group by `Product line` order by AVG_RATING desc;

---------------------------------------------------------------------------------------------------------------------------------------------------
-- Q15 : Count the sales occurrences for each time of day on every weekday.
select Days,TimeOfDay,Count('Invoice ID') as 'Sales Count' from amazon 
where Days not in ('Saturday','Sunday') group by Days,TimeOfDay order by Days,'Sales Count';
-- In this we not taking (Saturday,Sunday) because these are weekends.

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q16 : Identify the customer type contributing the highest revenue.
select `Customer type`,Sum(Total) as 'Highest Revenue' from amazon group by `Customer type` order by 'Highest Revenue';

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q17 : Determine the city with the highest VAT percentage.
select City , sum(`Tax 5%`) as 'Highest VAT%' from amazon group by City order by 'Highest VAT%' desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q18 : Identify the customer type with the highest VAT payments.
select `Customer type`,sum(`Tax 5%`) as 'Highest VAT%' from amazon group by `Customer type`order by 'Highest VAT%';

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q19 : What is the count of distinct customer types in the dataset?
select count(distinct `Customer type`) as `Customer type` from amazon;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q20 : What is the count of distinct payment methods in the dataset?
select Count(distinct Payment) as Payment_Method from amazon;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q21 : Which customer type occurs most frequently?
select `Customer type`,Count(`Invoice ID`) as 'No. Of Frequency' from amazon group by `Customer type`;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q22 : Identify the customer type with the highest purchase frequency.
select `Customer type`,Count(`Invoice ID`) as 'Highest Purchase Frequency' from amazon group by `Customer type`;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q23 : Determine the predominant gender among customers.
select Gender,Count(Gender) as Predominat_Gender from amazon group by Gender order by Predominat_Gender desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q24 : Examine the distribution of genders within each branch.
select Distinct Branch,Gender,count(*) as Count from amazon group by Branch, Gender order by Branch,Count desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q25 : Identify the time of day when customers provide the most ratings.
select TimeOfDay,Count(Rating) as Most_Rating from amazon group by TimeOfDay order by Most_Rating desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q26 : Determine the time of day with the highest customer ratings for each branch.
select Branch,TimeOfDay,Count(Rating) as Most_Rating from amazon group by Branch,TimeOfDay order by Branch,Most_Rating desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q27 : Identify the day of the week with the highest average ratings.
select Days,Avg(Rating) as Highest_AVG_Rating from amazon group by Days order by Highest_AVG_Rating desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Q28 : Determine the day of the week with the highest average ratings for each branch.
select Days,Branch,Avg(Rating) as Highest_AVG_Rating from amazon group by Days,Branch order by Highest_AVG_Rating desc;

--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------
-- SOME ANALYSIS BASED ON DATA:
---------------------
-- PRODUCT ANALYSIS:
---------------------
-- 1.There is 6 Product line given in Amazon Database.
-- 2.Most Attracting Product line for Female is Fassion Accessories.
-- 3.FOOD & BEVERAGES Product line has a HIGHEST REVENUE.
---------------------
-- SALES ANALYSIS:
---------------------
-- 1.NAPYTAW City has a Highest Revenue
-- 2.Highest Revenue Month is JANUARY.
-- 3.Member Cutomer has Contributed more for the Revenue.
---------------------
-- CUSTOMER ANALYSIS: 
--------------------- 
-- 1.EWallet is the Most Frequently Payment Method Used by Customer.
-- 2.Predominant Customer is Female.
-- 3.Customer provide the most rating at afternoon time.
-------------------------------------------------------------------------------------------------------------------------------------------
-- RECOMENDATIONS & IMPROVEMENTS :
-- 1. Underperformed Product line such as Health and Beauty could be improved by performing Offers for Customers.
-- 2. Develop More Market strategies/Offers for loyal and other Customer segments.
-------------------------------------------------------------------------------------------------------------------------------------------


